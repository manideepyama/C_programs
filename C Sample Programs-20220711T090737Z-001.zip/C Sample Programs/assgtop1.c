main()
{
	int a,b;
	printf("\nEnter a,b:");
	scanf("%d%d",&a,&b);
	a=a+b;
	printf("\nAdd=%d",a);
	a=a-b;
	printf("\nSub=%d",a);
	a=a*b;
	printf("\nMul=%d",a);
	a=a/b;
	printf("\nDiv=%d",a);
	a=a%b;
	printf("\nMod Div=%d",a);
	
}

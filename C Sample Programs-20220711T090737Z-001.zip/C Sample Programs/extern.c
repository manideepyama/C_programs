main()
{
	extern int a;
	printf("%d",a);
}
int a=1;

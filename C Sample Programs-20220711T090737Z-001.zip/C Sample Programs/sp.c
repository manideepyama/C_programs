#include<stdio.h>
int main()
{
	int cp=1400,sp,lp;
	lp=(cp/100)*15;
	sp=cp-lp;
	printf("%d",sp);

}

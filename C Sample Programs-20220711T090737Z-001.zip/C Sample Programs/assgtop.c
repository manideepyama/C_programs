main()
{
	int a,b;
	printf("\nEnter a,b:");
	scanf("%d%d",&a,&b);
	a+=b;
	a-=b;
	a*=b;
	a/=b;
	a%=b;
	printf("%d",a);
	
}

#include<stdio.h>
int main()
{
	int i=16;
	i=!i>15;
	printf("%d",i);
	return 0;
}
